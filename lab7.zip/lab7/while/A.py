n = int(input())
x = 1
while x**2 <= n:
    print(x**2)
    x += 1