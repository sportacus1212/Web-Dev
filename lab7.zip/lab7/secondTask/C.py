a = int(input())
b = int(input())

