def frontTimes(s,x):
    size
    if 3 > len(s): size = len(s)
    front = s[:size]
    return front*x