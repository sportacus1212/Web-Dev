def even(a):
    cnt=0
    for i in a:
        if i%2==0:cnt+=1
    return cnt