a = input ()
b = input ()

temp = a
a = b
b = temp

print(a, b)