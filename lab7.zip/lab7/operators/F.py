n = str(input())
print(n[-1])