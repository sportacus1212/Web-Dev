a = int(input())
b = int(input())

c = (a**2 + b**2)**0.5
print(c)