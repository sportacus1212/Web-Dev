a = int(input())
b = int(input())
c = int(input())

rub = a * c + (b * c)//100
kop = (b * c) % 100

print(rub, kop)