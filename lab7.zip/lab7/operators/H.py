n = str(input())

if len(n) > 1:
    print(n[-2])
else:
    print(0)
