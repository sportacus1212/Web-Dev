n = str(input())
suma = 0
for i in range(3):
    suma += int(n[i])
print(suma)