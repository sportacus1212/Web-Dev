def make_abba(a, b):
    return a+2*b+a