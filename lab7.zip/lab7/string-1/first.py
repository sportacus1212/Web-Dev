def first_half(str):
    return str[:len(str)/2]