def reverse3(a):
    b = []
    for i in a:
        b.append(i)
    return b