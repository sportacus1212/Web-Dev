def same(a):
    if(a[0]==a[-1]):return True
    return False