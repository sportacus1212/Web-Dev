def has23(a):
    if(a[0]==2 or a[0]==3 or a[1]==2 or a[1]==3): return True
    return False