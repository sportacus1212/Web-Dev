def rotate3(a):
    b = []
    b = a[1:]
    b.append(a[0])
    return b