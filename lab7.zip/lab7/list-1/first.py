def first6(a):
    if(a[0]==6 or a[len(a)-1]==6):
        return True
    return False