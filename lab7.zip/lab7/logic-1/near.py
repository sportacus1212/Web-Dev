def near_ten(num):
  within = num%10
  
  return within in [8,9,2,1,0]