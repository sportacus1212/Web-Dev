d = input()
x = input()
s = 0

for i in range(0,len(d)):
    if x == d[i]:
        s += 1

print(s)