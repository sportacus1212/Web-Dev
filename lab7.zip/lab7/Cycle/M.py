n = int(input())
s = 0
for i in range(n):
    if int(input()) == 0:
        s += 1
    else:
        continue
print(s)