n = int(input())
arr = list(map(int, input().split()))

arr.reverse()

print(*arr)
