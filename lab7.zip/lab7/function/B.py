def sqr(a, b):
    return a ** b

x = int(input())
e = int(input())
print(sqr(x, e))